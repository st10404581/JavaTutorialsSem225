/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progtestreview;

/**
 *
 * @author Hameed
 */
public class PROGTestReview {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Creating the 2D array for the number of jobs
        int[][] jobs = {
            {8, 2, 5},
            {7, 4, 5},
            {5, 5, 2},
            {2, 2, 3},
            {7, 7, 9},
            {7, 8, 5}
        };
        
        int row = 6;
        int column = 3;
        
        //Creating the 1D array for the headings
        String[] headings ={"Bathrooms","Kitchen","Garden"};
        
        //Creating the 1D array for the months
        String[] months ={"JAN","FEB","MAR","APR","MAY","JUN"};
        
        System.out.println("-".repeat(70));
        System.out.println("HOME MAKEOVER REPORT");
        System.out.println("-".repeat(70));
        
        //TABS BEING TOO WEIRD, RESORTING TO HARD CODING
//        //leaving tabs as per output
//        System.out.print("\t");
//        //displaying heading
//        for (int i = 0; i < headings.length; i++) {
//            System.out.print(headings[i]+"\t\t");
//        }

        System.out.println("\tBathrooms\tKitchens\tGarden");
        
//        //leaving a line
//        System.out.println("");
        
        //displaying table, jobs + months
        for (int i = 0; i < row; i++) {
            System.out.print(months[i]+"\t");
            for (int j = 0; j < column; j++) {
                System.out.print(jobs[i][j]+"\t\t");
            }
            System.out.println("");
        }// end of displaying
        
        //displaying heading for totals
        System.out.println("-".repeat(70));
        System.out.println("MONTHLY TOTALS");
        System.out.println("-".repeat(70));
        
        //creating array to store totals
        int[] totals = new int[6];
        //creating loop to count keep track of totals
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                totals[i] = totals[i]+jobs[i][j];
            }
//            System.out.println("total for " + months[i] + ": " + totals[i]);
        }
        
        //displaying totals and stars
        for (int i = 0; i < totals.length; i++) {
            if (totals[i] >= 15) {
                System.out.println(months[i]+"\t"+totals[i]+"\t"+"***");
            } else {
                System.out.println(months[i]+"\t"+totals[i]);
            }
        }
    }
    
}
